package Trabajos_Practicos.Trabajo_Sincronizacion;

class Cubierto {
    // Clase simple para representar un cubierto
}